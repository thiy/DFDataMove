#!/bin/sh
java -jar DFDataMove.jar